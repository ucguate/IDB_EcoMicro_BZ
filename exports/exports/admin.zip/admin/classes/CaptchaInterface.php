<?php
namespace PHPMaker2020\IDB_EcoMicro_BZ;

/**
 * Captcha interface
 */
interface CaptchaInterface
{
	public function getHtml();
	public function getConfirmHtml();
	public function validate();
	public function getScript();
}
?>